from vector2d import Vector2D

class Polygon:
    def __init__(self, sides):
        self.sides = sides
        self.vertices = []
