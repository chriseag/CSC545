#! /usr/bin/env python3

from environment import Environment

def greedySearch(env):
    #
    # TODO: return a path from start to goal using greedy search
    #
    return []

def uniformCostSearch(env):
    #
    # TODO
    #
    return []

def astarSearch(env):
    #
    # TODO
    #
    return []

if __name__ == '__main__':
    env = Environment('output/environment.txt')
    print("Loaded an environment with {} obstacles.".format(len(env.obstacles)))

    searches = {
        'greedy': greedySearch,
        'uniformcost': uniformCostSearch,
        'astar': astarSearch
    }

    for name, fun in searches.items():
        print("Attempting a search with " + name)
        Environment.printPath(name, fun(env))
